import math as mh
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pylab import *
import scipy
import scipy.stats
from scipy.stats import anderson
from scipy import integrate
from scipy.stats import gamma
from scipy.stats import beta
import time
from datetime import datetime
import timeit
import random


random.seed(0)
pd.set_option('display.max_columns', None)


def read_data():  # считывание данных из файла
    data = []
    with open("data.txt") as f:
        for line in f:
            data.append([float(x) for x in line.split()])
    return data


def relay(sigma, x):#функция плотности распределения Релэя
    f = 0
    f = x * mh.exp( - x ** 2 / (2 * sigma ** 2)) / (sigma ** 2)
    return f


def dens_relay(sigma, x):#функция распределения Релэя
    f = 0
    f = 1 - mh.exp( - x ** 2 / (2 * sigma ** 2))
    return f


def normal(miu, sigma, x):#функция плотности нормального распределения
    f = 0
    f = mh.exp( - (x - miu) ** 2 / (2 * sigma ** 2)) / (sigma * mh.sqrt(2 * mh.pi))
    return f


def dens_normal(miu, sigma, x):#функция плотности нормального распределения
    f = 0
    func = lambda y: mh.exp( - (y - miu) ** 2 / (2 * sigma ** 2)) / (sigma * mh.sqrt(2 * mh.pi))
    f = integrate.quad(func, -inf, x)
    return f[0]

def normal_gen(r):#функция получения нормально распределённых чисел по методу приближённой обратной функции (с апроксимацией 2)
    norm = 0
    if r >= 1/ 2 and r < 1:
        teta = mh.sqrt(- 2 * mh.log(r, mh.e))
        nom = 2.515517 + 0.802853 * teta + 0.010328 * teta ** 2
        denom = 1 + 1.432788 * teta + 0.189269 * teta ** 2 + 0.001308 * teta ** 3
        norm = nom / denom - teta
    if r > 0 and r <= 1 / 2:
        r = 1 - r
        teta = mh.sqrt(- 2 * mh.log(r, mh.e))
        nom = 2.515517 + 0.802853 * teta + 0.010328 * teta ** 2
        denom = 1 + 1.432788 * teta + 0.189269 * teta ** 2 + 0.001308 * teta ** 3
        norm = - (nom / denom - teta)
    return norm

def seq_gen(sigma, N):#генератор распределения Релэя
    seq = []#список для выборки
    norm_seq = []#список для вспомогательной выборки чисел нормального закона распределения
    norm_out = []#список для вспомогательной выборки чисел нормального закона распределения,
    # нужен для исследования качества вспомогательной выборки (проверка всех критериев, построение графиков)
    rav = 0#счётчик, который учитывает количество равномерно распределённых псевдослучайных числе,
    # которые потребовалось сгененрировать для моделирования выборки
    for i in range(N):
        for j in range(2):
            r = random.random()#получсаем равномерно распределённое число в границах (0, 1)
            norm = normal_gen(r)#помещаем равномерное число в функцию получения нормально распределённого числа
            norm_seq.append(norm)#число, распределённое по нормальному закону помещаем в список
            norm_out.append(norm)#число, распределённое по нормальному закону помещаем в список
        seq.append(sigma * mh.sqrt((norm_seq[0] ** 2 +  norm_seq[1] ** 2)))#используя два, полученных выше нормально распределённых числа
        # в формуле σ√(n1^2+n2^2), получаем число, распределённое по закону Релэя
        norm_seq.clear()#очищаем список нормально распределённых чисел
        rav += 2#счётчик равномерных чисел увеличиваем на 2
    return seq, rav, norm_out


def P_crit(Sk, r):  # Вычисление значения статистики
    coef = 1 / (np.power(2, (r / 2)) * mh.gamma(r / 2))
    func = lambda S: np.power(S, (r / 2 - 1)) * (np.power(mh.e, (- S / 2)))
    P = integrate.quad(func, Sk, np.inf)
    return P[0] * coef


def hi_2(x, alpha, sigma, f):
    print('Проверка критерия χ2:\n')
    Max = np.max(x)  # максимально возможный элемент в последовательности длиной N
    Min = np.min(x)  # минимально возможный элемент в последовательности длиной N
    h = Max - Min  # длина отрезка интервалов
    sum = 0
    v = []
    interval = []  # список граничных точек интервала

    # определяем число интервалов K
    K = int(mh.sqrt(len(x)))

    # заполняем список нулями
    for i in range(K + 1):
        interval.append(0)
    P = []
    # заполняем список граничными точками
    u = Min
    for i in range(K + 1):
        interval[i] = u
        u = interval[i] + h / K
    # заполняем список частот нулями
    for i in range(K):
        v.append(0)

    if f == 0:#0 - распределение Релэя, 1 - номральное распределения. Проверка нужна, чтобы можно было использовать тест для нескольких распределений
        for i in range(1, len(interval)):
            buf = dens_relay(sigma, interval[i]) - dens_relay(sigma, interval[i - 1])
            P.append(buf)
    if f == 1:
        for i in range(1, len(interval)):
            buf = dens_normal(0, 1, interval[i]) - dens_normal(0, 1, interval[i - 1])
            P.append(buf)
    # подсчет частоты попаданий элементов выборки в интервалы
    for i in range(len(x)):
        for j in range(K):
            if x[i] >= interval[j] and x[i] <= interval[j + 1]:
                v[j] += 1

    print("V = ", interval)
    print("P", P)
    for i in range(len(v)):
        v[i] /= len(x)  # отностельные частоты элементов
    print("V = ", v)
    vt = []# построение нормированной гистограммы
    for i in v:
        vt.append(i / (h / K)) #делим относительные частоты
    # график, построенный по группированным для критерия χ2 данным
    gridsize = (1, 1)
    fig = plt.figure(figsize=(14, 8))
    ax1 = fig.add_subplot()
    plt.xlabel('Интервалы')
    plt.ylabel('Частоты')
    ax1.hist(interval[:-1], bins=interval, weights=vt, rwidth=0.95)
    ax1.set_title('График, построеный по группированным для критерия χ2 данным')
    plt.show()
    # выбирам для какого распределения строить график плотности
    if f == 0:#для Релэя
        fig = plt.figure(figsize=(14, 8))
        ax0 = fig.add_subplot()
        y2 = []
        x2 = np.arange(Min, Max, 0.01)
        for o in x2:
            y2.append(relay(sigma, o))
        ax0.plot(x2, y2)  # График
        plt.show()
    if f == 1:#для Нормального
        fig = plt.figure(figsize=(14, 8))
        ax0 = fig.add_subplot()
        y2 = []
        x2 = np.arange(Min, Max, 0.01)
        for o in x2:
            y2.append(normal(0, 1, o))
        ax0.plot(x2, y2)  # График
        plt.show()
    # вычисляем сумму в формуле S(hi2)
    for i in range(K):
        sum += mh.pow((v[i] - P[i]), 2) / P[i]
    S = len(x) * sum  # умножаем сумму на объем выборки n

    r = K - 1  # число степеней свободы
    Sk = scipy.stats.chi2.ppf(1 - alpha, r)
    print(S, r)
    S_star = P_crit(S, r)
    if S_star > alpha:
        print('P {Sχ2 > Sχ2*}(достигнутый уровень значимости) = ', S_star)
        print('Проверка критерия χ2 окончена.\n')
        return 1, S, S_star  # гипотеза отвергается
    else:
        print('P {Sχ2 > Sχ2*}(достигнутый уровень значимости) = ', S_star)
        print('Проверка критерия χ2 окончена.\n')
        return 0, S, S_star  # гипотеза не отвергается



def K(S):
    sum = 0
    for i in range(-1000, 1000, 1):
        sum += (- 1) ** i * mh.exp(- 2 * i ** 2 * S ** 2)
    return sum


# Проверка гипотезы по критерию Колмогорова
def colmogorov_test(x, alpha, sigma, f):
    print('Проверка критерия Смирнова:\n')
    x_s = sorted(x)  # упорядочиваем выборку по возрастанию
    i = 0
    dp_buf = []
    dm_buf = []
    #выбираем, для какого распределения проводить поиск Dn+ и Dn-
    if f == 0:#для Релэя
        # Вычисляем Dn+
        for i in range(len(x) - 1):#запускаем цикл по выборке
            if x_s[i] != x_s[i + 1]:#если текущий элемент не равен следующиму
                dp_buf.insert(i, (i / len(x)) - dens_relay(sigma, x_s[i]))#добавляем в список Dn+ результат вычисления формулы (i / n) - F(σ, xi),
                # где n - длина выборки, F(σ, xi) - функция распределения Релэя от i-го элемента выборки
            else:#иначе
                if i == len(x) - 1 and x_s[i] == x_s[i + 1]:#если ещё не предпоследний элемент и текущий элемент не равен следующиму
                    dp_buf.insert(i + 1, (i + 1 / len(x)) - dens_relay(sigma, x_s[i + 1]))#добавляем в список Dn+ результат вычисления формулы (i / n) - F(σ, xi),
                # где n - длина выборки, F(σ, xi + 1) - функция распределения Релэя от i + 1-го элемента выборки

        # Вычисляем Dn-
        for i in range(len(x) - 1):#запускаем цикл по выборке
            if x_s[i] != x_s[i + 1]:#если текущий элемент не равен следующиму
                dm_buf.insert(i, dens_relay(sigma, x_s[i]) - ((i) / len(x)))#добавляем в список Dn+ результат вычисления формулы  F(σ, xi) - (i / n) ,
                # где n - длина выборки, F(σ, xi) - функция распределения Релэя от i-го элемента выборки
            else:#иначе
                if i == len(x) - 1 and x_s[i] == x_s[i + 1]:#если ещё не предпоследний элемент и текущий элемент не равен следующиму
                    dm_buf.insert(i + 1, dens_relay(sigma, x_s[i + 1]) - ((i) / len(x)))#добавляем в список Dn+ результат вычисления формулы  F(σ, xi) - (i / n) ,
                # где n - длина выборки, F(σ, xi) - функция распределения Релэя от i-го элемента выборки

    if f == 1:#для нормального
        # Вычисляем Dn+
        for i in range(len(x) - 1):
            if x_s[i] != x_s[i + 1]:
                dp_buf.insert(i, (i / len(x)) - dens_normal(0, 1, x_s[i]))
            else:
                if i == len(x) - 1 and x_s[i] == x_s[i + 1]:
                    dp_buf.insert(i + 1, (i + 1 / len(x)) - dens_normal(0, 1, x_s[i + 1]))

        # Вычисляем Dn-
        for i in range(len(x) - 1):
            if x_s[i] != x_s[i + 1]:
                dm_buf.insert(i, dens_normal(0, 1, x_s[i]) - ((i) / len(x)))
            else:
                if i == len(x) - 1 and x_s[i] == x_s[i + 1]:
                    dm_buf.insert(i + 1, dens_normal(0, 1, x_s[i + 1]) - ((i) / len(x)))

    D_p = max(dp_buf)#ищем максимум из Dn+
    D_m = max(dm_buf)#ищем максимум из Dn-
    D_n = max(mh.fabs(D_p), mh.fabs(D_m))#ищем максимум из найденных выше максимумов
    S = (6 * len(x) * D_n + 1) / (6 * mh.sqrt(len(x)))  # значение статистики S*
    k = K(S)
    P = 1 - k

    if P > alpha:
        print('P {S > S*}(достигнутый уровень значимости) = ', P)
        print('Проверка критерия Колмогорова окончена.\n')
        return 1, S, P  # гипотеза не отвергается
    else:
        print('P {S > S*}(достигнутый уровень значимости) = ', P)
        print('Проверка критерия Колмогорова окончена.\n')
        return 0, S, P  # гипотеза отвергается

data = []#массив входных данных
N = []#массив длин выборок

data = read_data()

for i in range(0, 3):
    N.append(int(data[i][0]))

sigma = data[3][0]
alpha = data[4][0]

seq = []#массив выборки
nor = []#массив моделирующей (вспомогательной) выборки
S = 0#количество равномерно распределённых чисел, потребовавшихся для моделирования выборок выше

for i in range(len(N)):
    start = timeit.default_timer()#таймер для подсчёта времени генерации
    seq, S, nor = seq_gen(sigma, N[i])
    end = timeit.default_timer() - start
    print(seq)
    print('Для моделирования выборки длиной', N[i], 'потребовалось', end, 'секунд и', S, 'равномерно распределённых элементов')
    h, St, P = hi_2(seq, alpha, sigma, 0)
    C, Stc, Pc = colmogorov_test(seq, alpha, sigma, 0)

    hh, Sth, Ph = hi_2(nor, alpha, sigma, 1)
    Ch, Stch, Pch = colmogorov_test(nor, alpha, sigma, 1)

    if i == 0:
        f = open("out_seq_50.txt", "w")#открываем на запись файл для результатов
    if i == 1:
        f = open("out_seq_200.txt", "w")
    if i == 2:
        f = open("out_seq_1000.txt", "w")

    p = 'Последовательность: '
    f.write(p)
    for u in seq:
        p = str(round(u, 3)) + ', '
        f.write(p)
    p = '\nВремея моделирования: ' + str(end) + ' секунд\n'
    f.write(p)
    p = 'Параметры последовательности: \n'
    f.write(p)
    p = 'n = ' + str(N[i]) + ' sigma = ' + str(sigma) + '\n'
    f.write(p)

    p = 'Для моделирования выборки потребовалось ' + str(S) + ' равномерно распределённых элементов' + '\n'
    f.write(p)
    p = 'КРИТЕРИЙ КОЛМОГОРОВА' + '\n'
    f.write(p)
    p = 'Значение статистики S: ' + str(Stc) + '\n'
    f.write(p)
    p = 'Достигнутый уровень значимости: ' + str(Pc) + '\n'
    f.write(p)
    if C:
        p = 'Критерий Колмогорова пройден, следовательно не причин для отклонения гипотезы о согласии распределения сгенерированной последовательности с Релэя распределением' + '\n'
        f.write(p)
    else:
        p = 'Критерий Колмогорова не пройден, следовательно гипотеза о согласии распределения сгенерированной последовательности с Релэя распределением отвергается' + '\n'
        f.write(p)

    p = 'КРИТЕРИЙ Xi^2' + '\n'
    f.write(p)
    p = 'Значение статистики S: ' + str(St) + '\n'
    f.write(p)
    p = 'Достигнутый уровень значимости: ' + str(P) + '\n'
    f.write(p)
    if h:
        p = 'Критерий Xi^2 пройден, следовательно не причин для отклонения гипотезы о согласии распределения сгенерированной последовательности с Релэя распределением' + '\n'
        f.write(p)
    else:
        p = 'Критерий Xi^2 не пройден, следовательно гипотеза о согласии распределения сгенерированной последовательности с Релэя распределением отвергается' + '\n'
        f.write(p)
    #проводим все тесты для моделирующей (вспомогательной) выборки
    p = 'ДАННЫЕ ВСПОМОГАТЕЛЬНОЙ ПОСЛЕДОВАТЕЛЬНОСТИ НОМРМАЛЬНОГО РАСПРЕДЕЛЕНИЯ' + '\n'
    f.write(p)
    p = 'Последовательность: '
    f.write(p)
    for u in range(50):
        p = str(round(nor[u], 3)) + ', '
        f.write(p)
    p = 'Параметры последовательности: \n'
    f.write(p)
    p = 'n = ' + str(len(nor)) + 'miu = 0' + ' sigma = 1' + '\n'
    f.write(p)

    p = 'КРИТЕРИЙ КОЛМОГОРОВА' + '\n'
    f.write(p)
    p = 'Значение статистики S: ' + str(Stch) + '\n'
    f.write(p)
    p = 'Достигнутый уровень значимости: ' + str(Pch) + '\n'
    f.write(p)
    if Ch:
        p = 'Критерий Колмогорова пройден, следовательно не причин для отклонения гипотезы о согласии распределения сгенерированной последовательности с нормальным распределением' + '\n'
        f.write(p)
    else:
        p = 'Критерий Колмогорова не пройден, следовательно гипотеза о согласии распределения сгенерированной последовательности с нормальным распределением отвергается' + '\n'
        f.write(p)

    p = 'КРИТЕРИЙ Xi^2' + '\n'
    f.write(p)
    p = 'Значение статистики S: ' + str(Sth) + '\n'
    f.write(p)
    p = 'Достигнутый уровень значимости: ' + str(Ph) + '\n'
    f.write(p)
    if hh:
        p = 'Критерий Xi^2 пройден, следовательно не причин для отклонения гипотезы о согласии распределения сгенерированной последовательности с нормальным распределением' + '\n'
        f.write(p)
    else:
        p = 'Критерий Xi^2 не пройден, следовательно гипотеза о согласии распределения сгенерированной последовательности с нормальным распределением отвергается' + '\n'
        f.write(p)

    f.close()




