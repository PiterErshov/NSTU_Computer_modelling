﻿import math as mh
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pylab import *
import scipy
import scipy.stats
from scipy import integrate
from scipy.stats import gamma

pd.set_option('display.max_columns', None)


def read_data():  # считывание данных из файла
    data = []
    with open("data.txt") as f:
        for line in f:
            data.append([float(x) for x in line.split()])
    return data


def seq_gen(a, b, c, x_t, N, m):  # генератор псевдослучайной последовательности
    x = []
    x_n = 0
    x_p = 0

    for i in range(N):
        x_n = (a * x_t + b * x_p + c) % m
        x_p = x_t
        x_t = x_n
        x.insert(i, x_n)
    return x


def C(n, k):  # сочетания из n по k
    c = mh.factorial(n) / ((mh.factorial(k)) * mh.factorial(n - k))
    return c


def Negative_binomial(s,
                      p):  # генерация последовательности вероятностей по негативному биномиальному закону распределения
    P = []
    ef = 0
    out = []
    k = 0
    deg_f = 0
    buf = C(s + k - 1, k) * p ** s * (1 - p) ** k
    if buf >= 0.001:
        deg_f += 1
    P.insert(0, buf)
    ef += 10
    while sum(P) <= 1:
        if k > 1000:
            break
        k += 1
        buf = C(s + k - 1, k) * P[k - 1] ** s * ((1 - P[k - 1]) ** k)
        if buf >= 0.001:
            deg_f += 1
        P.insert(k, buf)
        ef += 10
    if sum(P) > 1:
        for i in range(len(P) - 1):
            out.insert(i, P[i])
        out.insert(len(P), 1 - sum(out))
        return out, ef, deg_f
    return P, ef, deg_f


def s_algorithm(a, b, c, x, m, n, s, p):  # стандартный алгоритм получения дискретно распределённых случайных величин
    seq = []  # последовательность
    ro = seq_gen(a, b, c, x, n, m)  # набор псевдослучайных чисел
    deg_f = 0  # степень свободы (количество вероятностей P >= 0.001)
    ef = 0  # эффективность алгоритма (число операций)
    P, ef, deg_f = Negative_binomial(s, p)  # получаем вероятности случайных величин
    for i in range(n):
        M = ro[i]
        j = 0
        while j < len(P):
            M -= P[j]
            if M >= 0:
                j += 1
                ef += 1
            else:
                seq.insert(i, j)
                break
            ef += 1
        ef += 1
    return seq, ef, P, deg_f


def Poisson_dist(lda):  # генерация последовательности вероятностей по негативному биномиальному закону распределения
    P = []
    Q = 0
    k = 0
    deg_f = 0  # степень свободы (количество вероятностей P >= 0.001)
    buf = (lda ** k * mh.e ** (-lda)) / mh.factorial(k)
    if buf >= 0.001:
        deg_f += 1
    P.insert(0, buf)
    ef = 5  # эффективность алгоритма (число операций)
    while sum(P) <= 1:
        k += 1
        buf = (lda ** k * mh.e ** (-lda)) / mh.factorial(k)
        if buf >= 0.001:
            deg_f += 1
        P.insert(k, buf)
        if k == 18:
            Q = sum(P)
            ef += 2
        ef += 6
    return P, Q, ef, deg_f


def un_algorithm(a, b, c, x, m, n,
                 lda):  # не стандартный алгоритм получения дискретно распределённых случайных величин (распределение Пуассона)
    seq = []
    ro = seq_gen(a, b, c, x, n, m)  # набор псевдослучайных чисел
    deg_f = 0  # степень свободы (количество вероятностей P >= 0.001)
    ef = 0  # эффективность алгоритма (число операций)
    P, Q, ef, deg_f = Poisson_dist(lda)  # получаем вероятности случайных величин
    ef = 0  # эффективность алгоритма (число операций)
    # print(P)
    for i in range(n):
        ef += 1
        M = ro[i] - Q
        # print(M)
        j = lda
        if M < 0:
            while 1:
                M += P[j]
                if M < 0:
                    j -= 1
                    ef += 2
                else:
                    ef += 1
                    seq.insert(i, j)
                    break
                ef += 1
        else:
            while 1:
                j += 1
                M -= P[j]
                if M < 0:
                    seq.insert(i, j)
                    break
                ef += 2
    return seq, ef, P, deg_f


def find(x, y):  # проверка принадлежности элемента y выборке x
    for i in range(len(x)):
        if y == x[i]:
            return 1
    return 0


def unique(x):  # выделение последовательности уникальных элементов из выборки x
    un_seq = []  # набор уникальных элементов последовательности
    un_seq.insert(0, x[0])
    i = 1
    j = 1
    for i in range(len(x)):
        fl = find(un_seq, x[i])
        if fl == 0:
            un_seq.insert(j, x[i])
            j += 1
    return un_seq


def P_crit(Sk, r):  # Вычисление значения статистики
    coef = 1 / (np.power(2, (r / 2)) * mh.gamma(r / 2))
    func = lambda S: np.power(S, (r / 2 - 1)) * (np.power(mh.e, (- S / 2)))
    P = integrate.quad(func, Sk, np.inf)
    return P[0] * coef


def f_it(x, xi):  # посчёт числа встречи элемента xi в выборке x
    n = 0
    for i in range(len(x)):
        if x[i] == xi:
            n += 1
    return n


# Проверка гипотезы по критерию хи квадрат
def hi_2(x, alpha, N, p, lda, P, deg_f):
    print('Проверка критерия χ2:\n')
    sum = 0  # Значение статистики S
    v = []

    # определяем число интервалов K
    un_seq = unique(x)  # массив уникальных элементов последовательности
    K = deg_f

    un_sort = sorted(un_seq)  # сортировка уникальных элементов по возростанию

    # подсчет частоты встречи уникльных элементов в последовательности
    for i in range(len(un_seq)):
        v.append(f_it(x, un_sort[i]))
    print('Уникальные элементы', un_sort)
    print("V = ", v)

    v_n = []
    for i in range(len(v)):
        v_n.append(v[i] / len(x))  # отностельные частоты элементов
    print("V = ", v_n)
    P_theor = []  # теоритическая вероятность
    for i in un_sort:
        P_theor.append(i)
    P_u = []  # полученная вероятность встречи элемента в последовательности
    for i in un_sort:
        P_u.append(P[i])
    print(P_u)
    # график, построенный по группированным для критерия χ2 данным
    fig = plt.figure(figsize=(14, 8))
    ax = fig.add_subplot()
    plt.bar(un_sort, v_n, align='edge', color='green', alpha=0.4)  # Гистограмма
    ax.plot(P_theor[:len(v)], P_u[:len(v)])  # График
    plt.xlabel('Элементы')
    plt.ylabel('Частоты')
    if N == 40:
        if p == 0.2:
            ax.set_title('График, построенный по группированным для критерия χ2 данным для n = 40 p = 0,2')
        if p == 0.5:
            ax.set_title('График, построенный по группированным для критерия χ2 данным для n = 40 p = 0,5')
        if p == 0.8:
            ax.set_title('График, построенный по группированным для критерия χ2 данным для n = 40 p = 0,8')
    else:
        if p == 0.2:
            ax.set_title('График, построенный по группированным для критерия χ2 данным для n = 100 p = 0,2')
        if p == 0.5:
            ax.set_title('График, построенный по группированным для критерия χ2 данным для n = 100 p = 0,5')
        if p == 0.8:
            ax.set_title('График, построенный по группированным для критерия χ2 данным для n = 100 p = 0,8')
    if lda != -1:
        if N == 40:
            ax.set_title('График, построенный по группированным для критерия χ2 данным для n = 40')
        else:
            ax.set_title('График, построенный по группированным для критерия χ2 данным для n = 100')
    plt.show()

    # вычисляем сумму в формуле S(hi2)
    if deg_f > len(un_seq):
        d = len(un_seq)
    else:
        d = deg_f
    for i in range(d):
        sum += mh.pow(((v[i] / len(x)) - P_u[i]), 2) / P_u[i]
    S = len(x) * sum  # умножаем сумму на объем выборки n

    print('S = ', S)
    r = K - 1  # число степеней свободы
    print("R = ", r)
    S_star = P_crit(S, r)
    if S_star > alpha:
        print('P {Sχ2 > Sχ2*}(достигнутый уровень значимости) = ', S_star)
        print('Проверка критерия χ2 окончена.\n')
        return 1, S, S_star  # гипотеза отвергается
    else:
        print('P {Sχ2 > Sχ2*}(достигнутый уровень значимости) = ', S_star)
        print('Проверка критерия χ2 окончена.\n')
        return 0, S, S_star  # гипотеза не отвергается


data = read_data()

a = int(data[0][0])
b = int(data[1][0])
c = int(data[2][0])
m = data[3][0]
x = int(data[4][0])
n1 = int(data[5][0])
n2 = int(data[6][0])
lda = int(data[7][0])
s = int(data[8][0])
p1 = data[9][0]
p2 = data[10][0]
p3 = data[11][0]
alpha = data[12][0]

print("Стаднартный алгоритм")
print("N = 40")
seq_n40_1, ef40_1, P40_1, deg40_1 = s_algorithm(a, b, c, x, m, n1, s, p1)
h40_1, s40_1, st40_1 = hi_2(seq_n40_1, 0.05, n1, p1, -1, P40_1, deg40_1)
print("P = 0,2: ", seq_n40_1, 'Число действий', ef40_1, 'Вероятности', P40_1)
print("Hi^2: ", h40_1, s40_1, st40_1)

seq_n40_2, ef40_2, P40_2, deg40_2 = s_algorithm(a, b, c, x, m, n1, s, p2)
h40_2, s40_2, st40_2 = hi_2(seq_n40_2, 0.05, n1, p2, -1, P40_2, deg40_2)
print("P = 0,5: ", seq_n40_2, 'Число действий', ef40_2, 'Вероятности', P40_2)
print("Hi^2: ", h40_2, s40_2, st40_2)

seq_n40_3, ef40_3, P40_3, deg40_3 = s_algorithm(a, b, c, x, m, n1, s, p3)
h40_3, s40_3, st40_3 = hi_2(seq_n40_3, 0.05, n1, p3, -1, P40_3, deg40_3)
print("P = 0,8: ", seq_n40_3, 'Число действий', ef40_3, 'Вероятности', P40_3)
print("Hi^2: ", h40_3, s40_3, st40_3)

print("N = 100")
seq_n100_1, ef100_1, P100_1, deg100_1 = s_algorithm(a, b, c, x, m, n2, s, p1)
h100_1, s100_1, st100_1 = hi_2(seq_n100_1, 0.05, n2, p1, -1, P100_1, deg100_1)
print("P = 0,2: ", seq_n100_1, 'Число действий', ef100_1, 'Вероятности', P100_1)
print("Hi^2: ", h100_1, s100_1, st100_1)

seq_n100_2, ef100_2, P100_2, deg100_2 = s_algorithm(a, b, c, x, m, n2, s, p2)
h100_2, s100_2, st100_2 = hi_2(seq_n100_2, 0.05, n2, p2, -1, P100_2, deg100_2)
print("P = 0,5: ", seq_n100_2, 'Число действий', ef100_2, 'Вероятности', P100_2)
print("Hi^2: ", h100_2, s100_2, st100_2)

seq_n100_3, ef100_3, P100_3, deg100_3 = s_algorithm(a, b, c, x, m, n2, s, p3)
h100_3, s100_3, st100_3 = hi_2(seq_n100_3, 0.05, n2, p3, -1, P100_3, deg100_3)
print("P = 0,8: ", seq_n100_3, 'Число действий', ef100_3, 'Вероятности', P100_3)
print("Hi^2: ", h100_3, s100_3, st100_3)

print("Нестаднартный алгоритм")
print("N = 40")
seq_n40, ef40, P40, deg40 = un_algorithm(a, b, c, x, m, n1, lda)
h40, s40, st40 = hi_2(seq_n40, 0.05, n1, p1, lda, P40, deg40)
print('Последовательность', seq_n40, 'Число действий', ef40, 'Вероятности', P40)
print("Hi^2: ", h40, s40, st40)

print("N = 100")
seq_n100, ef100, P100, deg100 = un_algorithm(a, b, c, x, m, n2, lda)
h100, s100, st100 = hi_2(seq_n100, 0.05, n2, p1, lda, P100, deg100)
print('Последовательность', seq_n100, 'Число действий', ef100, 'Вероятности', P100)
print("Hi^2: ", h100, s100, st100)

f = open("out_seq_40_0.2_standart.txt", "w")
p = 'Последовательность: '
f.write(p)
for i in seq_n40_1:
    p = str(i) + ','
    f.write(p)

p = '\n' + 'Число операций: ' + str(ef40_1)
f.write(p)
p = '\n' + 'Эффективноесть: ' + str(1 / ef40_1)
f.write(p)
p = '\n' + 'Значение статистики S: ' + str(s40_1) + '\n'
f.write(p)
p = 'Достигнутый уровень значимости: ' + str(st40_1) + '\n'
f.write(p)
if h40_1:
    p = 'Критери Xi^2 пройден, следовательно не причин для отклонения гипотезы о согласии распределения сгенерированной последовательности с равномерным распределением' + '\n'
    f.write(p)
else:
    p = 'Критери Xi^2 не пройден, следовательно гипотеза о согласии распределения сгенерированной последовательности с равномерным распределением отвергается' + '\n'
    f.write(p)
f.close()

f = open("out_seq_40_0.5_standart.txt", "w")
p = 'Последовательность: '
f.write(p)
for i in seq_n40_2:
    p = str(i) + ','
    f.write(p)
p = '\n' + 'Число операций: ' + str(ef40_2)
f.write(p)
p = '\n' + 'Эффективноесть: ' + str(1 / ef40_2)
f.write(p)
p = '\n' + 'Значение статистики S: ' + str(s40_2) + '\n'
f.write(p)
p = 'Достигнутый уровень значимости: ' + str(st40_2) + '\n'
f.write(p)
if h40_2:
    p = 'Критери Xi^2 пройден, следовательно не причин для отклонения гипотезы о согласии распределения сгенерированной последовательности с равномерным распределением' + '\n'
    f.write(p)
else:
    p = 'Критери Xi^2 не пройден, следовательно гипотеза о согласии распределения сгенерированной последовательности с равномерным распределением отвергается' + '\n'
    f.write(p)
f.close()

f = open("out_seq_40_0.8_standart.txt", "w")
p = 'Последовательность: '
f.write(p)
for i in seq_n40_3:
    p = str(i) + ','
    f.write(p)

p = '\n' + 'Число операций: ' + str(ef40_3)
f.write(p)
p = '\n' + 'Эффективноесть: ' + str(1 / ef40_3)
f.write(p)
p = '\n' + 'Значение статистики S: ' + str(s40_3) + '\n'
f.write(p)
p = 'Достигнутый уровень значимости: ' + str(st40_3) + '\n'
f.write(p)
if h40_3:
    p = 'Критери Xi^2 пройден, следовательно не причин для отклонения гипотезы о согласии распределения сгенерированной последовательности с равномерным распределением' + '\n'
    f.write(p)
else:
    p = 'Критери Xi^2 не пройден, следовательно гипотеза о согласии распределения сгенерированной последовательности с равномерным распределением отвергается' + '\n'
    f.write(p)
f.close()

f = open("out_seq_100_0.2_standart.txt", "w")
p = 'Последовательность: '
f.write(p)
for i in seq_n100_1:
    p = str(i) + ','
    f.write(p)
p = '\n' + 'Число операций: ' + str(ef100_1)
f.write(p)
p = '\n' + 'Эффективноесть: ' + str(1 / ef100_1)
f.write(p)
p = '\n' + 'Значение статистики S: ' + str(s100_1) + '\n'
f.write(p)
p = 'Достигнутый уровень значимости: ' + str(st100_1) + '\n'
f.write(p)
if h100_1:
    p = 'Критери Xi^2 пройден, следовательно не причин для отклонения гипотезы о согласии распределения сгенерированной последовательности с равномерным распределением' + '\n'
    f.write(p)
else:
    p = 'Критери Xi^2 не пройден, следовательно гипотеза о согласии распределения сгенерированной последовательности с равномерным распределением отвергается' + '\n'
    f.write(p)
f.close()

f = open("out_seq_100_0.5_standart.txt", "w")
p = 'Последовательность: '
f.write(p)
for i in seq_n100_2:
    p = str(i) + ','
    f.write(p)
p = '\n' + 'Число операций: ' + str(ef100_2)
f.write(p)
p = '\n' + 'Эффективноесть: ' + str(1 / ef100_2)
f.write(p)
p = '\n' + 'Значение статистики S: ' + str(s100_2) + '\n'
f.write(p)
p = 'Достигнутый уровень значимости: ' + str(st100_2) + '\n'
f.write(p)
if h100_2:
    p = 'Критери Xi^2 пройден, следовательно не причин для отклонения гипотезы о согласии распределения сгенерированной последовательности с равномерным распределением' + '\n'
    f.write(p)
else:
    p = 'Критери Xi^2 не пройден, следовательно гипотеза о согласии распределения сгенерированной последовательности с равномерным распределением отвергается' + '\n'
    f.write(p)
f.close()

f = open("out_seq_100_0.8_standart.txt", "w")
p = 'Последовательность: '
f.write(p)
for i in seq_n100_3:
    p = str(i) + ','
    f.write(p)
p = '\n' + 'Число операций: ' + str(ef100_3)
f.write(p)
p = '\n' + 'Эффективноесть: ' + str(1 / ef100_3)
f.write(p)
p = '\n' + 'Значение статистики S: ' + str(s100_3) + '\n'
f.write(p)
p = 'Достигнутый уровень значимости: ' + str(st100_3) + '\n'
f.write(p)
if h100_3:
    p = 'Критери Xi^2 пройден, следовательно не причин для отклонения гипотезы о согласии распределения сгенерированной последовательности с равномерным распределением' + '\n'
    f.write(p)
else:
    p = 'Критери Xi^2 не пройден, следовательно гипотеза о согласии распределения сгенерированной последовательности с равномерным распределением отвергается' + '\n'
    f.write(p)
f.close()

f = open("out_seq_40_un_standart.txt", "w")
p = 'Последовательность: '
f.write(p)
for i in seq_n40:
    p = str(i) + ','
    f.write(p)
p = '\n' + 'Число операций: ' + str(ef40)
f.write(p)
p = '\n' + 'Эффективноесть: ' + str(1 / ef40)
f.write(p)
p = '\n' + 'Значение статистики S: ' + str(s40) + '\n'
f.write(p)
p = 'Достигнутый уровень значимости: ' + str(st40) + '\n'
f.write(p)
if h40:
    p = 'Критери Xi^2 пройден, следовательно не причин для отклонения гипотезы о согласии распределения сгенерированной последовательности с равномерным распределением' + '\n'
    f.write(p)
else:
    p = 'Критери Xi^2 не пройден, следовательно гипотеза о согласии распределения сгенерированной последовательности с равномерным распределением отвергается' + '\n'
    f.write(p)
f.close()

f = open("out_seq_100_un_standart.txt", "w")
p = 'Последовательность: '
f.write(p)
for i in seq_n100:
    p = str(i) + ','
    f.write(p)
p = '\n' + 'Число операций: ' + str(ef100)
f.write(p)
p = '\n' + 'Эффективноесть: ' + str(1 / ef100)
f.write(p)
p = '\n' + 'Значение статистики S: ' + str(s100) + '\n'
f.write(p)
p = 'Достигнутый уровень значимости: ' + str(st100) + '\n'
f.write(p)
if h100:
    p = 'Критери Xi^2 пройден, следовательно не причин для отклонения гипотезы о согласии распределения сгенерированной последовательности с равномерным распределением' + '\n'
    f.write(p)
else:
    p = 'Критери Xi^2 не пройден, следовательно гипотеза о согласии распределения сгенерированной последовательности с равномерным распределением отвергается' + '\n'
    f.write(p)
f.close()
