import math as mh
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pylab import *
import scipy
import scipy.stats
from scipy import integrate
from scipy.stats import gamma

# выводит максимальное количество строк в консоли
pd.set_option('display.max_columns', None)


def read_data():  # считывание данных из файла
    data = []
    with open("data.txt") as f:
        for line in f:
            data.append([int(x) for x in line.split()])
    return data

def period(x):  # поиск периода
    per = 1
    step = 0
    while per + step != len(x):
        if x[step] != x[per + step]:
            per += 1
            step = 0
        else:
            step += 1
    return per

def seq_gen(a, b, c, x_t, N, m):  # генератор псевдослучайной последовательности
    x = []
    x_n = 0
    x_p = 0

    for i in range(N):
        x_n = (a * x_t + b * x_p + c) % m
        x_p = x_t
        x_t = x_n
        x.insert(i, x_n)
    return x

def seq_gen_rand( N, m):  # генератор псевдослучайной последовательности
    x = []
    np.random.seed()
    for i in range(N):
        x_n = np.random.uniform(0, m)
        x.insert(i, x_n)
    return x

def Q_num(x, n):  # подсчёт числа ситуаций типа Xi > Xi+1 (количество перестановок для Теста №1)
    Q = 0
    for i in range(n - 1):
        if x[i] > x[i + 1]:
            Q += 1
    return Q

# Тест №1 (тест на случайность)
def random_test(Q, n):
    M = n / 2
    Q1 = Q - (U * mh.sqrt(n)) / 2
    Q2 = Q + (U * mh.sqrt(n)) / 2
    #print('[ %.3f' %  Q1, '(', M, ')','%.3f' % Q2, ']')

    if M >= Q1 and M <= Q2:
        return 1
    else:
        return 0

# Тест №1 (тест на случайность)
def test_1(x_T, n1, n2):
    print('Тест №1 начат:\n')
    # если тест при n=40 и n=100 выполняется, то и сам тест выполнен
    T1 = random_test(Q_num(x_T, n1), n1)
    T2 = random_test(Q_num(x_T, n2), n2)
    if T1 == 1 and T2 == 1:
        print('Тест №1 завершён.\n')
        return 1
    else:
        if T1 != 1:
            print('Тест №1 для n =', n1, 'не пройден.\n')
        if T2 != 1:
            print('Тест №1 для n =', n2, 'не пройден.\n')
        print('Тест №1 завершён.\n')
        return 0


def M_x(x, n):  # вычисление мат ожидания
    Mx = 0
    for i in range(n):
        Mx += x[i]
    return Mx / n


def D_x(x, n):  # вычисление дисперсии
    Mx = M_x(x, n)
    Dx = 0
    for i in range(n):
        Dx += (x[i] - Mx) ** 2
    return Dx / (n - 1)


# Тест №2
def uniform_test(test_seq, m, n, K, U, alpha):
    v = []
    nu = []
    inter = []
    out = []
    fl = 0

    # заполняем список нулями
    for i in range(K + 1):
        inter.insert(i, 0)

    # заполняем список граничными точками
    u = 0
    for i in range(K + 1):
        inter[i] = u
        u = inter[i] + m / K

    # заполняем список частот нулями
    for i in range(K):
        v.insert(i, 0)

    # подсчет в интервале элементов сгенерированной последовательности
    for i in range(len(test_seq)):
        for j in range(K):
            if test_seq[i] >= inter[j] and test_seq[i] <= inter[j + 1]:
                v[j] += 1

    # рассчитаем относительные частоты попаданий в интервалы
    for i in range(len(v)):
        nu.insert(i, v[i] / n)
        # ВЫВОД ГИСТОГРАММ

    Mx = M_x(test_seq, n)  # вычисляем мат ожидание
    Dx = D_x(test_seq, n)  # вычисляем дисперсию

    P = 1 / K  # вероятность попадания в интервал
    coef = U * mh.sqrt((K - 1) / n) / K  # часть формулы вычисления доверительного интервала

    #print("Границы доверительных интервалов для n =", n, "\n")
    b = 0  # temp переменная
    for i in range(len(nu)):
        # вычисляем доверительный интервал
        right = nu[i] + coef
        left = nu[i] - coef
        #print('[%.3f' %  left, '; %.3f' %  right, "]\n")
        if P > right or P < left:  # проверка на выход за пределы интервалов
            fl = 1
            out.insert(b, i)
            b += 1
    if fl == 1:
        return out, inter, nu
    else:
        # Оценим сходимость оценок математического ожидания и дисперсии
        Mx_t = m / 2
        Dx_t = m ** 2 / 12
        M_coef = U * mh.sqrt(Dx) / mh.sqrt(n)

        Xi_m_alpha = scipy.stats.chi2.ppf(1 - alpha / 2, n - 1)
        Xi_alpha = scipy.stats.chi2.ppf(alpha / 2, n - 1)

        D_left = (n - 1) * Dx / Xi_m_alpha
        D_right = (n - 1) * Dx / Xi_alpha

        if Mx_t > Mx + M_coef or Mx_t < Mx - M_coef:
            return 0, inter, nu
        if Dx_t < D_left or Dx_t > D_right:
            return 0, inter, nu

    return 1, inter, nu

# Тест №2
def test_2(test_seq_n40, test_seq_n100, m, n1, n2, K, U, alpha, flag):
    #print('Тест №2 начат:\n')
    inter1 = []
    inter2 = []
    nu1 = []
    nu2 = []
    u_40, inter1, nu1 = uniform_test(test_seq_n40, m, n1, K, U, alpha)
    u_100, inter2, nu2 = uniform_test(test_seq_n100, m, n2, K, U, alpha)
    if flag == 2:
        gridsize = (5, 5)
        fig = plt.figure(figsize=(15, 6))
        ax1 = plt.subplot2grid(gridsize, (1, 0), colspan=2, rowspan=3)
        plt.xlabel('Интервалы')
        plt.ylabel('Частота')
        ax2 = plt.subplot2grid(gridsize, (1, 3), colspan=2, rowspan=3)
        ax1.hist(inter1[:-1], bins=inter1, weights=nu1, rwidth=0.95)
        plt.xlabel('Интервалы')
        plt.ylabel('Частота')
        ax2.hist(inter2[:-1], bins=inter2, weights=nu2, rwidth=0.95)
        ax1.set_title('Гистограмма попадания частот в каждый интервал для n = 40')
        ax2.set_title('Гистограмма попадания частот в каждый интервал для n = 100')
        plt.show()

    if u_40 == 1 and u_100 == 1:
        return 1
    else:
        if u_40 != 1:
            ch40 = []
            b = 0
            for i in range(len(nu1)):  # выбор интервалов при ошибке n=40
                if b < len(u_40):
                    if i == u_40[b]:
                        ch40.insert(b, nu1[i])
                        b += 1
            print("Ошибка в тесте №2, при n=40. Выход за пределы интервала для", len(u_40), "частот.\n Частоты:", ch40)

        if u_100 != 1:
            ch100 = []
            b = 0
            for i in range(len(nu2)):  # выбор интервалов при ошибке n=100
                if b < len(u_100):
                    if i == u_100[b]:
                        ch100.insert(b, nu2[i])
                        b += 1
            print("Ошибка в тесте №2, при n=100. Выход за пределы интервала для", len(u_100), "частот.\n Частоты:",  ch100)
        print('Тест №2 завершён.\n')
        return 0

# Тест №3
def test_3(x_T, m, n1, n2, K, r, U, alpha, flag):
    print('Тест №3 начат:\n')
    x_1 = []  # подпоследовательность 1
    x_2 = []  # подпоследовательность 2
    t = mh.floor((len(x_T) - 1) / r)  # округление до меньшего целого

    # выделение подпоследовательности из основной последовательности (периода)
    for i in range(t):
        x_1.insert(i, x_T[i * r + 1])
    for i in range(t):
        x_2.insert(i, x_T[i * r + 2])

    T1 = test_1(x_1, n1, n2)
    T1_2 = test_1(x_2, n1, n2)
    T2 = test_2(x_1, x_2, m, n1, n2, K, U, alpha, flag)
    # для прохождения теста №3, необходимо, чтобы все подпоследовательности прошли тесты №1 и №2
    if T1 == 1 and T1_2 == 1 and T2 == 1:
        print('Тест №3 завершён.\n')
        return 1
    else:
        if T1 != 1:
            print('Тест №1 для первой подпоследовательнойти не пройден.\n')
        if T1_2 != 1:
            print('Тест №1 для второй подпоследовательнойти не пройден.\n')
        if T2 != 1:
            print('Тест №2 не пройден.\n')
        print('Тест №3 завершён.\n')
        return 0

def P_crit(Sk, r):#Вычисление значения статистики
    coef = 1 / (np.power(2, (r / 2)) * mh.gamma(r / 2))
    func = lambda S: np.power(S, (r / 2 - 1)) * (np.power(mh.e, (- S / 2 )))
    P = integrate.quad(func, Sk, np.inf)
    #print(mh.gamma(r / 2))
    return P[0] * coef

# Проверка гипотезы по критерию хи квадрат
def hi_2(x, alpha):
    print('Проверка критерия χ2:\n')
    Max = 0  # максимально возможный элемент в последовательности длиной N
    sum = 0
    n = mh.sqrt(len(x))
    v = []
    interval = []  # список граничных точек интервала

    # определяем число интервалов K
    K = int(n)

    # заполняем список нулями
    for i in range(K + 1):
        interval.insert(i, 0)

    # заполняем список граничными точками
    u = 0
    for i in range(K + 1):
        interval[i] = u
        u = interval[i] + len(x) / K

    P = 1 / n  # вероятность попадания в интервал

    # заполняем список частот нулями
    for i in range(K):
        v.insert(i, 0)

    # подсчет частоты попаданий элементов выборки в интервалы
    for i in range(len(x)):
        for j in range(K):
            if x[i] >= interval[j] and x[i] <= interval[j + 1]:
                v[j] += 1
    print(len(x))
    # график, построенный по группированным для критерия χ2 данным
    gridsize = (1, 1)
    fig = plt.figure(figsize=(14, 8))
    ax1 = plt.subplot2grid(gridsize, (0, 0), colspan=2, rowspan=3)
    plt.xlabel('Интервалы')
    #xticks(range(len(interval)), [ i for i in range(len(interval))])
    plt.ylabel('Частоты')
    ax1.hist(interval[:-1], bins=interval, weights=v, rwidth=0.95)
    ax1.set_title('График, построенный по группированным для критерия χ2 данным')
    plt.show()
    # вычисляем сумму в формуле S(hi2)
    for i in range(K):
        sum += mh.pow(((v[i] / len(x)) - P), 2) / P
    S = len(x) * sum  # умножаем сумму на объем выборки n

    r = K - 1  # число степеней свободы
    Sk = scipy.stats.chi2.ppf(1 - alpha, r)
    S_star = P_crit(Sk, r)
    if S_star > alpha:
        print('P {Sχ2 > Sχ2*}(достигнутый уровень значимости) = ', S_star)
        print('Проверка критерия χ2 окончена.\n')
        return 0, S, S_star  # гипотеза отвергается
    else:
        print('P {Sχ2 > Sχ2*}(достигнутый уровень значимости) = ', S_star)
        print('Проверка критерия χ2 окончена.\n')
        return 1, S, S_star   # гипотеза не отвергается


# Проверка гипотезы по критерию Смирнова
def smirnov_test(x, alpha, m):
    print('Проверка критерия Смирнова:\n')
    x_s = sorted(x)  # упорядочиваем выборку по возрастанию
    i = 0
    dp_buf = []
    dm_buf = []

    func_rav = lambda x, m: x / (m + 1)  # функция равномерного распределения

    # Вычисляем Dn+
    for i in range(len(x) - 1):
        if x_s[i] != x_s[i + 1]:
            dp_buf.insert(i, (i / len(x)) - func_rav(x_s[i], m))
        else:
            if i == len(x) - 1 and x_s[i] == x_s[i + 1]:
                dp_buf.insert(i + 1, (i + 1 / len(x)) - func_rav(x_s[i + 1], m))

    # Вычисляем Dn-
    for i in range(len(x) - 1):
        if x_s[i] != x_s[i + 1]:
            dm_buf.insert(i, func_rav(x_s[i], len(x)) - ((i) / len(x)))
        else:
            if i == len(x) - 1 and x_s[i] == x_s[i + 1]:
                dm_buf.insert(i + 1, func_rav(x_s[i + 1], m) - ((i) / len(x)))

    D_p = max(dp_buf)
    D_m = max(dm_buf)
    D_n = max(mh.fabs(D_p), mh.fabs(D_m))
    S = mh.pow(6 * len(x) * D_n + 1, 2) / (9 * len(x))  # значение статистики S*
    P = mh.e ** (-S / 2)

    if P > alpha:
        print('P {S > S*}(достигнутый уровень значимости) = ', P)
        print('Проверка критерия Смирнова окончена.\n')
        return 1, S, P  # гипотеза не отвергается
    else:
        print('P {S > S*}(достигнутый уровень значимости) = ', P)
        print('Проверка критерия Смирнова окончена.\n')
        return 0, S, P  # гипотеза отвергается

# Main

x = []  # список для сгенерированной псевдослучайной последовательности
x_T = []  # подпоследовательность с уникальными числами (период)
n1 = 40  # длина тестируемой последовательности (для теста 1, 2)
n2 = 100
U = 1.960  # квантиль для теста 1, 2 (взяли из таблички)
alpha = 0.05 # уровень значимости
K2 = 20 # количество интервалов для теста 2
K3 = 8  # количество интервалов для теста 3
r = 2 # количество подпоследовательностей для теста 3

# считываем данные из файла и помещаем в переменные
data = read_data()
a = data[0][0]
b = data[1][0]
c = data[2][0]
m = data[3][0]  # число, от которого берем остаток от деления
x_t = data[4][0]  # xn из генератора (текущее значение икса)
N = data[5][0]  # количество чисел в генерируемой последовательности

n1_3 = int(n1 / r)  # 40 / r
n2_3 = int(n2 / r)  # 100 / r

test_seq_n40 = seq_gen(a, b, c, x_t, n1, m)
test_seq_n100 = seq_gen(a, b, c, x_t, n2, m)
"""
x = seq_gen(a, b, c, x_t, N, m)  # получение псевдослучайной последовательности
invert_x = x
invert_x.reverse() # инвертирование последовательности для получения периода с конца последовательности
T = period(invert_x)  # получение числа непрерывной уникальной подпоследовательности

for i in range(T):
    x_T.insert(i, invert_x[i])  # выделение уникальной части последовательности длиной в период T
print(T)

#последовательности, полученные встроенным генератором
#"""
x_r = seq_gen_rand(N, m)
invert_x = x_r
invert_x.reverse()
T = period(invert_x)
test_seq_n40 = seq_gen_rand(n1, m)
test_seq_n100 = seq_gen_rand(n2, m)

for i in range(m - 1):
    x_T.insert(i, invert_x[i])  # выделение уникальной части последовательности длиной в период T

print(len(x_T))
#print(x_r)
#print(x_T)
#"""

if T == N:
    print("Период отсутствует.\n")
if T < 100:
    print("Период последовательности меньше 100, следовательно, последовательность не исследуем.\n")
    f = open("out_seq.txt", "w")
    # Если период < 100, то пишем в файл сгенерированную последовательность
    for i in x:
        p = str(i) + ','
        f.write(p)
    f.close()

    # Если период < 100, то пишем в файл период
    f = open("out_period.txt", "w")
    for i in x_T:
        p = str(i) + ','
        f.write(p)
    f.close()

    f = open("out_data.txt", "w")
    p = 'a = ' + data[0][0] + '\n'
    f.write(p)
    p = 'b = ' + data[1][0] + '\n'
    f.write(p)
    p = 'c = ' + data[2][0]  + '\n'
    f.write(p)
    p = 'm = ' + data[3][0]  + '\n'  # число, от которого берем остаток от деления
    f.write(p)
    p = 'x_t = ' + data[4][0]  + '\n' # xn из генератора (текущее значение икса)
    f.write(p)
    p = 'N = ' + data[5][0]  + '\n' # количество чисел в генерируемой последовательности
    f.write(p)
    p = 'T(период последовательности) = ' + T
    f.write(p)
    f.close()
else:

    f = open("out_seq.txt", "w")
    # Если период < 100, то пишем в файл сгенерированную последовательность
    for i in x:
        p = str(i) + ','
        f.write(p)
    f.close()

    f = open("out_period.txt", "w")
    for i in x_T:
        p = str(i) + ','
        f.write(p)
    f.close()
    f = open("out_data.txt", "w")
    p = 'a = ' + str(data[0][0]) + '\n'
    f.write(p)
    p = 'b = ' + str(data[1][0]) + '\n'
    f.write(p)
    p = 'c = ' + str(data[2][0]) + '\n'
    f.write(p)
    p = 'm = ' + str(data[3][0]) + '\n'  # число, от которого берем остаток от деления
    f.write(p)
    p = 'x_t = ' + str(data[4][0]) + '\n'  # xn из генератора (текущее значение икса)
    f.write(p)
    p = 'N = ' + str(data[5][0]) + '\n'  # количество чисел в генерируемой последовательности
    f.write(p)
    p = 'T(период последовательности) = ' + str(T) + '\n'
    f.write(p)

    # print(x_T) # вывод всей подпоследовательности (периода)
    # print("Чисел в подпоследовательности: ", T, "\n")
    T1 = test_1(x_T, n1, n2)
    if T1 == 1:
        p = 'Тест 1 пройден, следовательно последовательность близка к случайной' + '\n'
        f.write(p)
    else:
        p = 'Тест 1 не пройден, следовательно последовательность не близка случайной' + '\n'
        f.write(p)
    print("Тест №1\n", T1, "\n")

    flag = 2
    T2 = test_2(test_seq_n40, test_seq_n100, m, n1, n2, K2, U, alpha, flag)
    print("Тест №2\n", T2, "\n")
    if T2 == 1:
        p = 'Тест 2 пройден, следовательно последовательность возможно равномерная' + '\n'
        f.write(p)
    else:
        p = 'Тест 2 не пройден, следовательно последовательность не равномерная' + '\n'
        f.write(p)
    flag = 3
    T3 =  test_3(x_T, m, n1_3, n2_3, K3, r, U, alpha, flag)
    if T3 == 1:
        p = 'Тест 3 пройден, следовательно последовательность возможно равномерная и близка к случайной' + '\n'
        f.write(p)
    else:
        p = 'Тест 3 не пройден, следовательно последовательность не равномерная и не близка к случайной' + '\n'
        f.write(p)

    print("Test 3", T3)
    hi, Sk, S_star = hi_2(x_T, alpha)
    if hi == 1:
        p = 'Критери Xi^2 пройден, следовательно не причин для отклонения гипотезы о согласии распределения сгенерированной последовательности с равномерным распределением' + '\n'
        f.write(p)
    else:
        p = 'Критери Xi^2 не пройден, следовательно гипотеза о согласии распределения сгенерированной последовательности с равномерным распределением отвергается' + '\n'
        f.write(p)
    print("Критерий Xi^2\n", hi, "\n")
    p = 'Значение статистики S = ' + str(Sk) + '\n'
    f.write(p)
    p = 'P {S > S*}(достигнутый уровень значимости для Xi^2) = ' + str(S_star) + '\n'
    f.write(p)
    Smirnov, S, P = smirnov_test(x_T, alpha, m)
    p = 'S(значение статистики для критерия Смирнова) = ' + str(S) + '\n'
    f.write(p)
    p = 'P {S > S*}(достигнутый уровень значимости для критерия Смирнова) = ' + str(P) + '\n'
    f.write(p)
    if Smirnov == 1:
        p = 'Критери Смирнова пройден, следовательно не причин для отклонения гипотезы о согласии распределения сгенерированной последовательности с равномерным распределением' + '\n'
        f.write(p)
    else:
        p = 'Критери Смирнова не пройден, следовательно гипотеза о согласии распределения сгенерированной последовательности с равномерным распределением отвергается' + '\n'
        f.write(p)
    print("Критерий Смирнова\n", Smirnov, "\n")
    f.close()
