import math as mh
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pylab import *
import scipy
import scipy.stats
from scipy.stats import anderson
from scipy import integrate
from scipy.stats import gamma
import time
from datetime import datetime
import timeit
import random

random.seed(0)
pd.set_option('display.max_columns', None)


def read_data():  # считывание данных из файла
    data = []
    with open("data.txt") as f:
        for line in f:
            data.append([float(x) for x in line.split()])
    return data


def Bess(miu, v):#функция Бесселя
    func = lambda x: np.power(x, miu - 1) * np.power(1 - x, v - 1)
    P = integrate.quad(func, 0, 1)
    return P[0]


def beta(miu, v, x):#функция плотности бета распределения
    f = 0
    if x >= 0 and x <= 1:
        f = mh.pow(x, miu - 1) * mh.pow(1 - x, v - 1) / Bess(miu, v)
    return f


def dens_beta(miu, v, x):#функция бета распределения
    f = 0
    func = lambda y: np.power(y, miu - 1) * np.power(1 - y, v - 1) / Bess(miu, v)
    f = integrate.quad(func, 0, x)
    return f[0]


def intervals(miu, v):#функция вычисления границ, в которых содержиться
    a = 0
    b = 0
    f = lambda x: np.power(x, miu - 1) * np.power(1 - x, v - 1) / Bess(miu, v)#функция плотности распределения
    i = 0
    while 1:#поиск левой границы
        buf = integrate.quad(f, 0, i)#высичляем интегла до тех пор, пока он не достигнет 0.01
        if buf[0] >= 0.01:
            a = i
            break
        else:
            i += 0.001
    i = 0
    while 1:#поиск правой границы
        buf = integrate.quad(f, 0, i)#высичляем интегла до тех пор, пока он не достигнет 0.99
        if buf[0] >= 0.99:
            b = i
            break
        else:
            i += 0.001
    return a, b

def f_max(a, b, miu, v):#фнукция поиска значения x при котором функция плотности максимальна
    Mx = 0
    I = []
    y = []
    x = np.arange(a, b, 0.001)
    for i in x:
        y.append(beta(miu, v, i))
        I.append(i)
    m = max(y)
    for i in range(len(y)):
        if y[i] == m:
            Mx = I[i]
            break
    return Mx

def cont_seq(left, right, miu, v, N):# функция генератор псевдослучайной последовательности
    seq = []
    MAX = f_max(left, right, miu, v) #ищем x при котором функцяи плотности максимальна на отрезке [a, b]
    M = beta(miu, v, MAX) #ищем коэффициент М, который используется своместно с y0
    j = 0 #число равномерных псевдослучайных чисел, которые потребовались для генерации посдедовательности
    for i in range(N):
        x = []
        while 1:
            for k in range(2):
                x_n = random.random()
                x.append(x_n)
            x0 = left + x[0] * (right - left)
            y0 = x[1] * M
            if y0 < beta(miu, v, x0):
                seq.append(x0)
                break
            j += 2
            x.clear()#всегда очищаем пару равномерно распределённхы чисел
    return seq, j


def P_crit(Sk, r):  # Вычисление значения статистики
    coef = 1 / (np.power(2, (r / 2)) * mh.gamma(r / 2))
    func = lambda S: np.power(S, (r / 2 - 1)) * (np.power(mh.e, (- S / 2)))
    P = integrate.quad(func, Sk, np.inf)
    return P[0] * coef


def hi_2(x, alpha, V, miu):
    print('Проверка критерия χ2:\n')
    Max = np.max(x)  # максимально возможный элемент в последовательности длиной N
    Min = np.min(x)  # минимально возможный элемент в последовательности длиной N
    h = Max - Min  # длина отрезка интервалов
    sum = 0
    v = []
    interval = []  # список граничных точек интервала

    # определяем число интервалов K
    K = int(mh.sqrt(len(x)))

    # заполняем список нулями
    for i in range(K + 1):
        interval.append(0)
    P = []
    # заполняем список граничными точками
    u = Min
    for i in range(K + 1):
        interval[i] = u
        u = interval[i] + h / K
    # заполняем список частот нулями
    for i in range(K):
        v.append(0)

    for i in range(1, len(interval)):
        buf = dens_beta(miu, V, interval[i]) - dens_beta(miu, V, interval[i - 1])
        P.append(buf)
    # подсчет частоты попаданий элементов выборки в интервалы
    for i in range(len(x)):
        for j in range(K):
            if x[i] >= interval[j] and x[i] <= interval[j + 1]:
                v[j] += 1

    print("V = ", interval)
    print("P", P)
    for i in range(len(v)):
        v[i] /= len(x)  # отностельные частоты элементов
    print("V = ", v)
    vt = []# построение нормированной гистограммы
    for i in v:
        vt.append(i / (h / K)) #делим относительные частоты
    # график, построенный по группированным для критерия χ2 данным
    gridsize = (1, 1)
    fig = plt.figure(figsize=(14, 8))
    ax1 = fig.add_subplot()
    plt.xlabel('Интервалы')
    plt.ylabel('Частоты')
    ax1.hist(interval[:-1], bins=interval, weights=vt, rwidth=0.95)
    ax1.set_title('График, построеный по группированным для критерия χ2 данным')
    plt.show()
    # вычисляем сумму в формуле S(hi2)
    for i in range(K):
        sum += mh.pow((v[i] - P[i]), 2) / P[i]
    S = len(x) * sum  # умножаем сумму на объем выборки n

    r = K - 1  # число степеней свободы
    Sk = scipy.stats.chi2.ppf(1 - alpha, r)
    print(S, r)
    S_star = P_crit(S, r)
    if S_star > alpha:
        print('P {Sχ2 > Sχ2*}(достигнутый уровень значимости) = ', S_star)
        print('Проверка критерия χ2 окончена.\n')
        return 1, S, S_star  # гипотеза отвергается
    else:
        print('P {Sχ2 > Sχ2*}(достигнутый уровень значимости) = ', S_star)
        print('Проверка критерия χ2 окончена.\n')
        return 0, S, S_star  # гипотеза не отвергается


def a2(S):
    func = lambda y: mh.exp((S / (8 * (y ** 2 + 1))) - (mh.pow(4 * i + 1, 2) * mh.pi ** 2 * y ** 2) / (8 * S))
    A = 0
    for i in range(20):
        a1 = math.gamma(i + 1 / 2) * (4 * i + 1)
        a2 = math.gamma(1 / 2) * math.gamma(i + 1)
        par = - mh.pow(4 * i + 1, 2) * mh.pi * mh.pi / (8 * S)
        a3 = mh.exp(par)
        a4 = integrate.quad(func, 0, mh.inf)
        A += ((-1) ** i) * a1 * a3 * a4[0] / a2
    A *= mh.sqrt(2 * mh.pi) / S
    return A

def O2_AD(x, miu, v, alpha):
    print('Проверка критерия омега^2-Андерсона-Дарлинга:\n')
    x_s = sorted(x)  # СѓРїРѕСЂСЏРґРѕС‡РёРІР°РµРј РІС‹Р±РѕСЂРєСѓ РїРѕ РІРѕР·СЂРѕСЃС‚Р°РЅРёСЋ
    S = 0
    k = 0
    for i in range(1, len(x)):
        F = dens_beta(miu, v, x_s[i - 1])
        h = len(x) - k
        if abs(F) > 0.01 and abs(1 - F) > 0.01:
            p1 = ((2 * i - 1) * mh.log(F, mh.e) / (2 * h))
            p2 = 1 - (2 * i - 1) / (2 * h)
            p3 = mh.log(1 - F, mh.e)
            S += p1 + p2 * p3
        else:
            print('Fail\n')
            k += 1
    print(k, len(x))
    S *= -2
    S -= h

    P = 1 - a2(S)
    if P > alpha:
        print('Проверка критерия омега^2-Андерсона-Дарлинга окончена.\n')
        return 1, S, P # РіРёРїРѕС‚РµР·Р° РЅРµ РѕС‚РІРµСЂРіР°РµС‚СЃСЏ
    else:
        print('Проверка критерия омега^2-Андерсона-Дарлинга окончена.\n')
        return 0, S, P # РіРёРїРѕС‚РµР·Р° РѕС‚РІРµСЂРіР°РµС‚СЃСЏ


data = read_data()#считывание данных из файла
alpha = data[9][0]#выделение уровня значимости

N = []#Список длин последовательностей
MIU = []#Список значений параметра мю
V = []#Список значений параметра ню
LT = []#Список значений левой границы
RT = []#Список значений правой границы

for i in range(0, 3):
    N.append(int(data[i][0]))

for i in range(3, 6):
    MIU.append(data[i][0])

for i in range(6, 9):
    V.append(data[i][0])
"""
for i in range(len(V)):#вычисление левых и правых границ для всех вариантов входых данных
    l, r = intervals(MIU[i], V[i])
    LT.append(l)
    RT.append(r)
"""
LT.append(0.059)
LT.append(0.021)
LT.append(0.277)
RT.append(0.942)
RT.append(0.869)
RT.append(0.988)
for i in range(len(N)):
    for j in range(len(V)):
        fl = 0 #флаг, обозначающий выполнение или не выполнение теста Андерсона-Дарлинга
        start = timeit.default_timer()#таймер для подсчёта времени генерации
        S, Y = cont_seq(LT[j], RT[j], MIU[j], V[j], N[i])
        end = timeit.default_timer() - start
        """fig = plt.figure(figsize=(14, 8))
        ax0 = fig.add_subplot()
        y2 = []
        #print("Количество псевдослучайных чисел, потребовавшихся для генерации последовательности", Y)
        x2 = np.arange(min(S), max(S), 0.001)
        for o in x2:
            y2.append(beta(MIU[j], V[j], o))
        ax0.plot(x2, y2)  # График
        plt.show()"""
        #print("Для моделирования выборки с параметрами: u =", MIU[j], " v =", V[j], " потребовалось ", end, " секунд")
        #h, s, St = hi_2(S, alpha, V[j], MIU[j])
        fl, sO, P = O2_AD(S, MIU[i], V[i], alpha)
        if i == 0:
            if j == 0:
                f = open("out_seq_50_1.txt", "w")
            if j == 1:
                f = open("out_seq_50_2.txt", "w")
            if j == 2:
                f = open("out_seq_50_3.txt", "w")
        if i == 1:
            if j == 0:
                f = open("out_seq_200_1.txt", "w")
            if j == 1:
                f = open("out_seq_200_2.txt", "w")
            if j == 2:
                f = open("out_seq_200_3.txt", "w")
        if i == 2:
            if j == 0:
                f = open("out_seq_1000_1.txt", "w")
            if j == 1:
                f = open("out_seq_1000_2.txt", "w")
            if j == 2:
                f = open("out_seq_1000_3.txt", "w")
        p = 'Последовательность: '
        f.write(p)
        for u in S:
            p = str(round(u, 3)) + ', '
            f.write(p)
        p = '\nВремея моделирования: ' + str(end) + ' секунд\n'
        f.write(p)
        p = 'Параметры последовательности: \n'
        p = 'n = ' + str(N[i]) + 'miu = ' + str(MIU[j]) + 'v = ' + str(V[j]) + '\n'
        f.write(p)

        p = 'Значение статистики S: ' + str(sO) + '\n'
        f.write(p)
        p = 'Достигнутый уровень значимости: ' + str(P) + '\n'
        f.write(p)
        if fl:
            p = 'Критери омега^2-Андерсона-Дарлинга пройден, следовательно не причин для отклонения гипотезы о согласии распределения сгенерированной последовательности с бета распределением' + '\n'
            f.write(p)
        else:
            p = 'Критери омега^2-Андерсона-Дарлинга не пройден, следовательно гипотеза о согласии распределения сгенерированной последовательности с бета распределением отвергается' + '\n'
            f.write(p)
        """  
        p = 'Значение статистики S: ' + str(s) + '\n'
        f.write(p)
        p = 'Достигнутый уровень значимости: ' + str(St) + '\n'
        f.write(p)
        if h:
            p = 'Критери Xi^2 пройден, следовательно не причин для отклонения гипотезы о согласии распределения сгенерированной последовательности с бета распределением' + '\n'
            f.write(p)
        else:
            p = 'Критери Xi^2 не пройден, следовательно гипотеза о согласии распределения сгенерированной последовательности с бета распределением отвергается' + '\n'
            f.write(p)
        f.close()"""