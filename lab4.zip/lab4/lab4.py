import math as mh
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pylab import *
import scipy
import scipy.stats
from scipy import integrate
from scipy.stats import gamma
import time
from datetime import datetime
import timeit
import random

pd.set_option('display.max_columns', None)


def read_data():  # считывание данных из файла
    data = []
    with open("data.txt") as f:
        for line in f:
            data.append([float(x) for x in line.split()])
    return data


def seq_gen(a, b, c, x_t, N, m):  # генератор псевдослучайной последовательности
    x = []
    x_n = 0
    x_p = 0

    for i in range(N):
        x_n = (a * x_t + b * x_p + c) % m
        x_p = x_t
        x_t = x_n
        x.insert(i, x_n)
    return x


def logist(v, miu, x):  # функция плотности логистического распределения
    return exp(-(x - miu) / v) / (v * (1 + exp(- (x - miu) / v)) ** 2)


def dens_logist(v, miu, x): # функция логистического распределения
    return 1 / (1 + mh.exp(-(x - miu) / v))


def cont_seq(v, miu, n, a):#генератор непрерывных псевдослучайных чисел
    seq = []
    for i in range(n):
        seq.append(miu - v * mh.log(1 / a[i] - 1, mh.e))
    return seq


def P_crit(Sk, r):  # Вычисление значения статистики
    coef = 1 / (np.power(2, (r / 2)) * mh.gamma(r / 2))
    func = lambda S: np.power(S, (r / 2 - 1)) * (np.power(mh.e, (- S / 2)))
    P = integrate.quad(func, Sk, np.inf)
    print(P[0], coef)
    return P[0] * coef


def hi_2(x, alpha, V, miu):
    print('Проверка критерия χ2:\n')
    Max = np.max(x)  # максимально возможный элемент в последовательности длиной N
    Min = np.min(x)  # минимально возможный элемент в последовательности длиной N
    h = Max - Min  # длина отрезка интервалов
    sum = 0
    v = []
    interval = []  # список граничных точек интервала

    # определяем число интервалов K
    K = int(5 * mh.log10(len(x)))

    # заполняем список нулями
    for i in range(K + 1):
        interval.append(0)

    # заполняем список граничными точками
    u = Min
    for i in range(K + 1):
        interval[i] = u
        u = interval[i] + h / K
    P = []

    print("Inter", interval)
    # заполняем список частот нулями
    for i in range(K):
        v.append(0)

    # подсчет частоты попаданий элементов выборки в интервалы
    for i in range(len(x)):
        for j in range(K):
            if x[i] >= interval[j] and x[i] <= interval[j + 1]:
                v[j] += 1

    print("V = ", v)
    for i in range(len(v)):
        v[i] /= len(x)  # отностельные частоты элементов
    print("V = ", v)
    for i in range(1, len(interval)):
        buf = dens_logist(V, miu, interval[i]) - dens_logist(V, miu, interval[i - 1])
        P.append(buf)
    print("P", P)

    fig = plt.figure(figsize=(14, 8))
    ax = fig.add_subplot()
    y1 = []
    x1 = np.arange(Min, Max, 0.1)
    for i in x1:
        y1.append(dens_logist(V, miu, i))
    ax.plot(x1, y1)  # График
    plt.show()

    fig = plt.figure(figsize=(14, 8))
    ax0 = fig.add_subplot()
    y2 = []
    x2 = np.arange(Min, Max, 0.1)
    for i in x2:
        y2.append(logist(V, miu, i))
    ax0.plot(x2, y2)  # График
    plt.show()

    # график, построенный по группированным для критерия χ2 данным
    gridsize = (1, 1)
    fig = plt.figure(figsize=(14, 8))
    ax1 = plt.subplot2grid(gridsize, (0, 0), colspan=2, rowspan=3)
    plt.xlabel('Интервалы')
    plt.ylabel('Частоты')
    ax1.hist(interval[:-1], bins=interval, weights=v, rwidth=0.95)
    ax1.set_title('График, построеный по группированным для критерия χ2 данным')
    plt.show()
    # вычисляем сумму в формуле S(hi2)
    for i in range(K):
        sum += mh.pow((v[i] - P[i]), 2) / P[i]
    S = len(x) * sum  # умножаем сумму на объем выборки n

    r = K - 1  # число степеней свободы
    Sk = scipy.stats.chi2.ppf(1 - alpha, r)
    print(S, r)
    S_star = P_crit(S, r)
    if S_star > alpha:
        print('P {Sχ2 > Sχ2*}(достигнутый уровень значимости) = ', S_star)
        print('Проверка критерия χ2 окончена.\n')
        return 1, S, S_star  # гипотеза отвергается
    else:
        print('P {Sχ2 > Sχ2*}(достигнутый уровень значимости) = ', S_star)
        print('Проверка критерия χ2 окончена.\n')
        return 0, S, S_star  # гипотеза не отвергается


def I(v, z):
    Iv = 0
    for i in range(20):
        I1 = (z / 2) ** (v + 2 * i)
        I1 /= mh.gamma(i + 1) * mh.gamma(i + v + 1)
        Iv += I1
    return Iv


def a1(s):
    al = 0
    for i in range(20):
        arg = ((4 * i + 1) ** 2) / (16 * s)
        a1 = math.gamma(i + 1 / 2) * math.sqrt(4 * i + 1)
        a1 *= math.exp(-arg)
        a1 *= I(-1 / 4, arg) - I(1 / 4, arg)
        a1 /= math.gamma(1 / 2) * math.gamma(i + 1)
        al += a1
    al *= 1 / math.sqrt(2 * s)
    return al


def O_mega_KMS(x, alpha, v, miu):
    print('Проверка критерия Омега квадрат:\n')
    x_s = sorted(x)  # упорядочиваем выборку по возростанию
    n = 0
    S = 0  # значение статистики критерия
    P = 0  # достигнутый уровень значимости
    for i in range(1, len(x_s)):
        S += mh.pow(dens_logist(v, miu, x_s[i - 1]) - (2 * i - 1) / (2 * len(x)), 2)
    S += 1 / (12 * len(x))

    P = 1 - a1(S)

    if P > alpha:
        print('P {S > S*}(достигнутый уровень значимости) = ', P)
        print('Проверка критерия Омега квадрат окончена.\n')
        return 1, S, P  # гипотеза не отвергается
    else:
        print('P {S > S*}(достигнутый уровень значимости) = ', P)
        print('Проверка критерия Омега квадрат окончена.\n')
        return 0, S, P  # гипотеза отвергается

data = read_data()

a = int(data[0][0])
b = int(data[1][0])
c = int(data[2][0])
m = data[3][0]
x = int(data[4][0])
n1 = int(data[5][0])
n2 = int(data[6][0])
n3 = int(data[7][0])
miu1 = data[8][0]
miu2 = data[9][0]
miu3 = data[10][0]
v1 = data[11][0]
v2 = data[12][0]
v3 = data[13][0]
alpha = data[14][0]

N = []
V = []
MIU = []
test = [1.2, 3, 12, 22, 23, 10, 14]
for i in range(5, 8):
    N.append(int(data[i][0]))

for i in range(8, 11):
    MIU.append(data[i][0])

for i in range(11, 14):
    V.append(data[i][0])

for i in range(len(N)):
    for j in range(len(V)):
        alp = seq_gen(a, b, c, x, N[i], m)
        start = timeit.default_timer()
        s1 = cont_seq(V[j], MIU[j], N[i], alp)

        end = timeit.default_timer() - start
        print("Для моделирования выборки с параметрами: u =", MIU[j], " v =", V[j], " потребовалось ", end, " секунд")
        h, s, S = hi_2(s1, alpha, V[j], MIU[j])
        O, O_s, P = O_mega_KMS(s1, alpha, V[j], MIU[j])
        if i == 0:
            if j == 0:
                f = open("out_seq_50_1.txt", "w")
            if j == 1:
                f = open("out_seq_50_2.txt", "w")
            if j == 2:
                f = open("out_seq_50_3.txt", "w")
        if i == 1:
            if j == 0:
                f = open("out_seq_200_1.txt", "w")
            if j == 1:
                f = open("out_seq_200_2.txt", "w")
            if j == 2:
                f = open("out_seq_200_3.txt", "w")
        if i == 2:
            if j == 0:
                f = open("out_seq_1000_1.txt", "w")
            if j == 1:
                f = open("out_seq_1000_2.txt", "w")
            if j == 2:
                f = open("out_seq_1000_3.txt", "w")
        p = 'Последовательность: '
        f.write(p)
        for u in s1:
            p = str(round(u, 3)) + ', '
            f.write(p)
        p = '\nВремея моделирования: ' + str(end) + ' секунд\n'
        f.write(p)
        """p = 'Параметры последовательности: \n'
        p = 'n = ' + str(N[i]) + 'miu = ' + str(MIU[j]) + 'v = ' + str(V[j]) + '\n'
        f.write(p)"""

        p = 'Значение статистики S: ' + str(O_s) + '\n'
        f.write(p)
        p = 'Достигнутый уровень значимости: ' + str(P) + '\n'
        f.write(p)
        if O:
            p = 'Критери омега^2-Крамера-Мизеса-Смирнова пройден, следовательно не причин для отклонения гипотезы о согласии распределения сгенерированной последовательности с логистическим распределением' + '\n'
            f.write(p)
        else:
            p = 'Критери омега^2-Крамера-Мизеса-Смирнова, следовательно гипотеза о согласии распределения сгенерированной последовательности с логистическим распределением отвергается' + '\n'
            f.write(p)

        p = 'Значение статистики S: ' + str(s) + '\n'
        f.write(p)
        p = 'Достигнутый уровень значимости: ' + str(S) + '\n'
        f.write(p)
        if h:
            p = 'Критери Xi^2 пройден, следовательно не причин для отклонения гипотезы о согласии распределения сгенерированной последовательности с логистическим распределением' + '\n'
            f.write(p)
        else:
            p = 'Критери Xi^2 не пройден, следовательно гипотеза о согласии распределения сгенерированной последовательности с логистическим распределением отвергается' + '\n'
            f.write(p)
        f.close()



